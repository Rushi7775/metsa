# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from django import template
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from functools import partial
import re
from textwrap import indent
from unittest import result
from django.http import HttpRequest
from django.shortcuts import render
from django.http import HttpResponse
import requests
import json 
from requests.auth import HTTPBasicAuth
import os
from pprint import pprint
import sys
from django.http import HttpRequest
from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpRequest
from requests.auth import HTTPBasicAuth
from django.http import HttpResponse
import json
import os
from elasticsearch import Elasticsearch
from pprint import pprint


@login_required(login_url="/login/")
def index(request):
	
  
    context = {'segment': 'index'}
    if request.method == 'GET': # If the form is submitted
        es = Elasticsearch(['https://localhost:9200'], http_auth=('elastic', 'yUzdyK6h09OrGfS3B6Np') ,verify_certs=False ,)
    #s = input("Enter the search param")
        search_query = request.GET.get('searchquery', None)

        filterop = request.GET.get('filterop', None)
        payload ={
       "query": {
			"bool": {
			"must": [
				{
				"multi_match": {
					"type": "best_fields",
					"query": search_query,
					"lenient": True
				
				}
				}
			],
			"filter": [],
			"should": [],
			"must_not": []
			}
		}
				
	}
	

    

  

        payload1={
		"query": {
			"multi_match": {
			"query": search_query,
			"type": "phrase"
			}
		}
		}


        print(payload)
        headers = {
        'Content-Type': "application/json",
        'Authorization': 'Basic ZWxhc3RpYzpXU0FVRVpSMVU4MXpKYTczdUMyXw=='
        }

        payload2={
			"query": {
				"bool": {
				"must": [
					{
					"bool": {
						"should": [
						{
							"match_phrase": dict()    
						}
						],
						"minimum_should_match": 1
					}
					}
				],
				"filter": [],
				"should": [],
				"must_not": []
				}
			},
			"highlight": {
				"pre_tags": [
				"@kibana-highlighted-field@"
				],
				"post_tags": [
				"@/kibana-highlighted-field@"
				],
				"fields": {
				"*": {}
				},
				"fragment_size": 2147483647
			}
			}
	
        if filterop == '0': #exact
            a = payload1
            status ='--Exact '
        elif filterop == '1':
            a = payload #multi
            status ='--Multiple'
         
        else:
            
            a=payload2
           
            if '=' in search_query:
       
                k,v=search_query.split('=')
                a["query"]["bool"]["must"][0]["bool"]["should"][0]["match_phrase"].update({k:v})
                status='--key'   
            else:
                status='Please enter in the format : key = value'
                return render(request , 'home.html' ,{'status': status} )

        responsee = es.search(index="metsa*", body =json.dumps(a))
        result = []
        for hit in responsee['hits']['hits']:
            result.append(hit["_source"])  
        count = len(result)    
        return render(request , 'home/index.html' ,{'response':result ,'count':count , 'search':search_query , 'status': status} )
 


@login_required(login_url="/login/")
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template('home/' + load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('home/page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('home/page-500.html')
        return HttpResponse(html_template.render(context, request))

        
        

def home(request):
    
    if request.method == 'GET': # If the form is submitted
        es = Elasticsearch(['https://localhost:9200'], http_auth=('elastic', 'yUzdyK6h09OrGfS3B6Np') ,verify_certs=False ,)
    #s = input("Enter the search param")
        search_query = request.GET.get('searchquery', None)

        filterop = request.GET.get('filterop', None)
        payload ={
       "query": {
    "bool": {
      "must": [
        {
          "multi_match": {
            "type": "best_fields",
            "query": search_query,
            "lenient": True
          
          }
        }
      ],
      "filter": [],
      "should": [],
      "must_not": []
    }
  }
    
}
  

    

  

        payload1={
  "query": {
    "multi_match": {
      "query": search_query,
      "type": "phrase"
    }
  }
}


        print(payload)
        headers = {
        'Content-Type': "application/json",
        'Authorization': 'Basic ZWxhc3RpYzpXU0FVRVpSMVU4MXpKYTczdUMyXw=='
        }

        payload2={
"query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "match_phrase": dict()    
              }
            ],
            "minimum_should_match": 1
          }
        }
      ],
      "filter": [],
      "should": [],
      "must_not": []
    }
},
   "highlight": {
    "pre_tags": [
      "@kibana-highlighted-field@"
    ],
    "post_tags": [
      "@/kibana-highlighted-field@"
    ],
    "fields": {
      "*": {}
    },
    "fragment_size": 2147483647
  }
}
 

     
        

        if filterop == '0': #exact
            a = payload1
            status ='--Exact '
        elif filterop == '1':
            a = payload #multi
            status ='--Multiple'
         
        else:
            
            a=payload2
           
            if '=' in search_query:
       
                k,v=search_query.split('=')
                a["query"]["bool"]["must"][0]["bool"]["should"][0]["match_phrase"].update({k:v})
                status='--key'   
            else:
                status='Please enter in the format : key = value'
                return render(request , 'home.html' ,{'status': status} )



       
        responsee = es.search(index="metsa*", body =json.dumps(a))
        print(responsee)
        result = []
        
        for hit in responsee['hits']['hits']:
            result.append(hit["_source"])
           
        count = len(result)    
        print("*"*10)
        
        pprint(result)
        print("*"*10)
        
        return render(request , 'home.html' ,{'response':result ,'count':count , 'search':search_query , 'status': status} )